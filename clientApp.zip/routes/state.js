var state = {}

state.srcClient = null;
state.desClient = null;
state.migration = null;


module.exports = state;
